
clear, clc, close;
% Number of k in K-nearest neighbor
opts.k = 5; 
% Ratio of validation data
ho = 0.2;
% Common parameter settings 
opts.N  = 20;     % number of solutions
opts.T  = 2;    % maximum number of iterations

% Load dataset
load beyinC2.mat; 
% Divide data into training and validation sets
HO = cvpartition(label,'HoldOut',ho); 
opts.Model = HO; 
% Perform feature selection 
FS     = jfs('pso',feat,label,opts);
% Define index of selected features
sf_idx = FS.sf;
% Accuracy  
%Acc    = jknn(feat(:,sf_idx),label,opts); 
Acc    = jsvm(feat(:,sf_idx),label,opts);

PSOfeat=feat(:,sf_idx);
FS2     = jfs('fa',PSOfeat,label,opts);
% Define index of selected features
sf_idx2 = FS2.sf;
% Accuracy  
%Acc    = jknn(feat(:,sf_idx),label,opts); 
Acc2    = jsvm(PSOfeat(:,sf_idx2),label,opts);

% Plot convergence
plot(FS2.c); grid on;
xlabel('Number of Iterations');
ylabel('Fitness Value');
title('PSOFA');
save('indexPSOFA_C2_SVM.mat','sf_idx2')


