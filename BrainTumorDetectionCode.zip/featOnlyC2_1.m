dataFolder='dataset/Train';
categories={'pituitary','notumor','meningioma','glioma'};

%imagedatastorelar
imds=imageDatastore(fullfile(dataFolder,categories),"LabelSource","foldernames");
imds.ReadFcn=@(filename)readandpreprocess(filename);


net=resnet101;
featureLayer='fc1000';

%özellik çıkarma
feat=activations(net,imds,featureLayer,"OutputAs","columns");


%etiketler
label=imds.Labels;
feat=feat';

save('beyinC2.mat','label','feat','-v7.3') %resnet101 fc1000 ile oluşturulan
