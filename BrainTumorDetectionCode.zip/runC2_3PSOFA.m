
dataFolderTrain='dataset/Train';
dataFolderTest='dataset/Test';

categories={'pituitary','notumor','meningioma','glioma'};


%imagedatastorelar
imdsTrain=imageDatastore(fullfile(dataFolderTrain,categories),"LabelSource","foldernames");
imdsTrain.ReadFcn=@(filename)readandpreprocess(filename);

imdsTest=imageDatastore(fullfile(dataFolderTest,categories),"LabelSource","foldernames");
imdsTest.ReadFcn=@(filename)readandpreprocess(filename);

net=resnet101;
featureLayer='fc1000';

%özellik çıkarma
trainingFeatures=activations(net,imdsTrain,featureLayer,"OutputAs","columns");
testingFeatures=activations(net,imdsTest,featureLayer,"OutputAs","columns");

%etiketler
trainingLabels=imdsTrain.Labels;
testingLabels=imdsTest.Labels;


%%
%PSOFA
%özellik seçme
load indexPSOFA_C2_SVM.mat;
trainingFeat=trainingFeatures(sf_idx',:);
testingFeat=testingFeatures(sf_idx',:);

bestPSOFA=0;
tic;
for i=1:30
        
        classifier=fitcecoc(trainingFeat,trainingLabels,"ObservationsIn","columns","Learners","linear");
        predictedLabels=predict(classifier,testingFeat,"ObservationsIn","columns");
        accuracy=mean(predictedLabels==testingLabels);

        if accuracy>bestPSOFA
                bestPSOFA=accuracy;
                save("modelPSOFAC2.mat","classifier","predictedLabels","testingLabels");
        end

        sonucAccPSOFA(i)=accuracy;
        disp(sprintf('İter:%d    Accuracy:%f     Best:%f',i,accuracy,bestPSOFA));
        
end
zamanPSOFA=toc;
eniyiPSOFA=max(sonucAccPSOFA);
ortalamaPSOFA=mean(sonucAccPSOFA);


disp(sprintf('Best accuracy PSOFA:%f',eniyiPSOFA));
disp(sprintf('Mean accuracy PSOFA:%f',ortalamaPSOFA));

load modelPSOFAC2.mat
cm = confusionchart(testingLabels,predictedLabels);




