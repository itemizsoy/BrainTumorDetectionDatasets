% Feature map visualization using DarkNet53


net = darknet53; %you can use resnet101 to visualize for resnet101


img = imread('Y1.jpg'); 
inputSize = net.Layers(1).InputSize(1:2);
imgResized = imresize(img, inputSize);


layerName = 'conv1';  


act = activations(net, imgResized, layerName, 'OutputAs', 'channels');


[numRows, numCols, numChannels] = size(act);


figure;
numDisplay = min(numChannels, 4);
rows = ceil(sqrt(numDisplay));
cols = ceil(numDisplay / rows);

for i = 1:numDisplay
    subplot(rows, cols, i);
    imagesc(act(:,:,i));
    axis off;
    title(['Channel ' num2str(i)]);
end

sgtitle(['Feature Maps for Model: DarkNet53 Layer: ' layerName ]);
colormap jet;
